# Tabungan Sahamku

Aplikasi Android sederhana untuk mencatat setoran tabungan saham dan target saham. Data disimpan secara lokal di perangkat menggunakan SharedPreferences.

## Membuat APK lewat GitHub Actions (tanpa komputer)

1. Unggah isi folder proyek ini ke sebuah repository GitHub.
2. Pastikan file `.github/workflows/build-apk.yml` ikut terunggah.
3. Buka tab **Actions** pada repository.
4. Pilih **Build Tabungan Sahamku APK**.
5. Tekan **Run workflow**, lalu konfirmasi **Run workflow**.
6. Setelah proses selesai dengan tanda centang hijau, buka hasil run tersebut.
7. Di bagian **Artifacts**, unduh `TabunganSahamku-APK`.
8. Ekstrak ZIP hasil unduhan dan pasang `app-debug.apk` di HP Android.

Build memerlukan koneksi internet. APK ini adalah debug APK untuk pemasangan pribadi, bukan rilis Play Store.
