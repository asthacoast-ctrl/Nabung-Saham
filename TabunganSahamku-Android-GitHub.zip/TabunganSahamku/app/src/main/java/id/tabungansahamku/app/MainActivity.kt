package id.tabungansahamku.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

data class Deposit(val month: Int, val amount: Long, val note: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { SavingsApp() } }
    }
}

@Composable
fun SavingsApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("savings", 0) }
    var balance by remember { mutableLongStateOf(prefs.getLong("balance", 50000L)) }
    var month by remember { mutableIntStateOf(prefs.getInt("month", 1)) }
    var deposits by remember {
        mutableStateOf(run {
            val arr = JSONArray(prefs.getString("history", """[{"month":1,"amount":50000,"note":"Setoran awal"}]"""))
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i); Deposit(o.getInt("month"), o.getLong("amount"), o.optString("note"))
            }
        })
    }
    var monthly by remember { mutableStateOf("50000") }
    var extra by remember { mutableStateOf("0") }
    var selected by remember { mutableStateOf("BBRI") }
    var target by remember { mutableStateOf("300000") }
    var note by remember { mutableStateOf("") }
    val money = remember { NumberFormat.getCurrencyInstance(Locale("in", "ID")) }
    fun save() {
        prefs.edit().putLong("balance", balance).putInt("month", month)
            .putString("history", JSONArray().apply {
                deposits.forEach { d -> put(JSONObject().put("month", d.month).put("amount", d.amount).put("note", d.note)) }
            }.toString()).apply()
    }
    val goal = target.toLongOrNull()?.coerceAtLeast(1L) ?: 300000L
    val progress = (balance.toFloat() / goal).coerceIn(0f, 1f)
    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("💰 Tabungan Sahamku", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Rencana menabung saham • 36 bulan", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                Card {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Total tabungan modal")
                        Text(money.format(balance), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                        Text("${(progress * 100).toInt()}% dari target ${money.format(goal)}")
                        Text("Sisa target: ${money.format((goal - balance).coerceAtLeast(0))}")
                    }
                }
            }
            item {
                Text("Catat setoran", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                OutlinedTextField(monthly, { monthly = it.filter(Char::isDigit) }, label = { Text("Setoran rutin (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(extra, { extra = it.filter(Char::isDigit) }, label = { Text("Tambahan modal (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(note, { note = it }, label = { Text("Catatan (opsional)") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val amount = (monthly.toLongOrNull() ?: 0L) + (extra.toLongOrNull() ?: 0L)
                    if (amount > 0) {
                        month += 1; balance += amount
                        deposits = deposits + Deposit(month, amount, note.ifBlank { "Setoran bulan $month" })
                        monthly = "50000"; extra = "0"; note = ""; save()
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Simpan setoran") }
            }
            item {
                Text("Target pembelian", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("BBCA", "BBRI", "BBNI", "BMRI").forEach { ticker ->
                        FilterChip(selected == ticker, onClick = { selected = ticker }, label = { Text(ticker) })
                    }
                }
                OutlinedTextField(target, { target = it.filter(Char::isDigit) }, label = { Text("Target dana (Rp)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                Text("Atur target sesuai harga 1 lot terbaru ditambah biaya transaksi.", style = MaterialTheme.typography.bodySmall)
            }
            item { Text("Riwayat setoran", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
            items(deposits.reversed()) { d ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("Bulan ${d.month}", fontWeight = FontWeight.SemiBold)
                            Text(d.note, style = MaterialTheme.typography.bodySmall)
                        }
                        Text("+${money.format(d.amount)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }
            item {
                OutlinedButton(onClick = {
                    balance = 0; month = 0; deposits = emptyList(); save()
                }, modifier = Modifier.fillMaxWidth()) { Text("Reset seluruh catatan") }
                Text("Data tersimpan di perangkat ini. Ekspor/cadangkan catatan secara berkala. Aplikasi tidak terhubung ke broker dan tidak melakukan transaksi saham.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
